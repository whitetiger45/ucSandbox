ucMail
======

Data Structures Assignment #3

http://www.cplusplus.com/reference/list/list/

http://stackoverflow.com/questions/12280593/accessing-elements-of-a-list-of-lists-in-c