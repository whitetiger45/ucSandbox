#ifndef COMMUNICATION_H
#define COMMUNICATION_H

//Data Structures and Algorithms in C++
//Michael T.Goodrich * Roberto Tamassia * David Mount
//Chapter 3 Arrays, Linked List & Recurssion

typedef string UMail;

class Communication
{

private:
    UMail m_ucemail;
    Communication* next;
    Communication* previous;

    friend class CLinkedList;
};

class CLinkedList
{
public:
    CLinkedList()
    {
        m_header = new Communication;
        m_trailer = new Communication;
        m_header->next = m_trailer;
        m_trailer->previous = m_trailer;
    }

    ~CLinkedList()
    {
        while(!empty())
            removeFront();
        delete m_header;
        delete m_trailer;
    }

    bool empty() const
    {
        return (m_header->next == m_trailer);
    }

    const UMail& front() const
    {//TO DO: Add exception if user tries to call this method on an empty list
        return m_header->next->m_ucemail;
    }

    const UMail& back() const
    {//TO DO: Add exception if user tries to call this method on an empty list
        return m_trailer->previous->m_ucemail;
    }

    void addFront(const UMail& u)//add to front of list
    {
        add(m_header->next, u);
    }

    void addBack(const UMail& u)//add to back of list
    {
        add(m_trailer, u);
    }

    void removeFront()//remove from front
    {//TO DO: Add exception if user tries to call this method on an empty list
        remove(m_header->next);
    }

    void removeBack()//remove from back
    {//TO DO: Add exception if user tries to call this method on an empty list
        remove(m_trailer->previous);
    }

private:
    Communication* m_header;
    Communication* m_trailer;

protected:

    void add(Communication* c, const UMail& u)//insert new node before v
    {
        Communication* cnode = new Communication;//create a new node for u
        cnode->m_ucemail = u;//link u in between
        cnode->next = c;//link cnode in between v
        cnode->previous = c->previous;//...and v->previous
        c->previous->next = c->previous = cnode;
    }

    void remove(Communication* c)//remove node c
    {
        Communication* cnodeprev = v->previous;//predecessor
        Communication* cnodenext = v->next;//successor
        cnodeprev->next = cnodenext;//unlink c from list;
        cnodenext->previous = cnodeprev;
        delete c;
    }

};


#endif // COMMUNICATION_H
