/*
 *Author: Bryan Kanu, Dan Wendelken, Jed Lantikus
 *Course title: Data Structures
 *Course number: CS2028
 *Instructor: Anca Ralescu
 *TA: Suryadip Chakraborty
 *Abstract: Assignment 3 main.cxx uses a doubly linked list to implement a simple email system.
 */

#include <algorithm>
#include <iostream>
#include <iterator>
#include <list>
#include <string>
#include <sstream>
#include <vector>

#include "dblLinkList.h"

using namespace std;

int main()
{
    cout << endl <<"Demostration of size and deletion commands: " << endl;
    Inbox<string> test;
    test.insertEmail("hello", "world", "list class", "this is a test");
    test.insertEmail("bob", "marley", "music", "just inputing random emails");
    test.insertEmail("Lebron James", "Michael Jordan", "NBA", "Good game last night!");
    test.insertEmail("Junior Gong", "Nas", "music", "what's with the new cd");
    test.insertEmail("stephen", "marley", "list class", "email three");
    test.DisplayInbox();
    cout<< endl <<"Size of music: " << test.communicationSize("music") << "\n";
    test.deleteCommNodes("music");
    cout << endl << "=====music deleted=====" << endl;
    test.DisplayInbox();
    cout << endl <<"======================================================"<< endl;
    cout <<"======================================================"<< endl;

    Inbox<string> mail;
    string input = "";
    cout << endl << "Build your own chain." << endl;
    cout <<"Enter email subject alone or additional details (comma delimited). " << endl;
    cout << "Format: [subject], [to], [from], [message]" << endl;
    cout << "Type 'done' to end input (-h for help):" << endl;
    while(input != "done"){
        getline(cin, input);
        size_t found = input.find(",");
        if (found!=string::npos){ //commas
            bool flag = true;

            istringstream ss(input);
            string token;
            string arr[] = {"[subject]", "[to]", "[from]", "[message]"};

            int x = 0;
            while(getline(ss, token, ',')) {
                if(x<4){
                    arr[x] = token;  
                    x++;
                }else{
                    cout << "Improper input format. See proper format below:" << endl;
                    cout << "Format: [subject], [to], [from], [message]" << endl;
                    flag = false;
                    break;
                }
            }
            if (flag == true){
                //cout << "----insert 1----"<< endl;
                mail.insertEmail(arr[1], arr[2], arr[0], arr[3]);
            } 
        } else if(input == "-h"){
            cout << "Format:[subject], [to], [from], , [message]" << endl;
        } else {
            if (input!="done"){
                //cout << "----insert 2----"<< endl;
                mail.insertEmail("[empty]", "[empty]", input, "[empty]");
            }
        }
    }

    cout << endl <<"+++++++++++++++++++++++++++++++++++++"<< endl;
    cout << "Your inbox:" << endl;
    cout <<"+++++++++++++++++++++++++++++++++++++"<< endl;
    mail.DisplayInbox();




    // Inbox<string> test2;
    // test2.insertEmail("[empty]", "[empty]", "test", "[empty]");
    // test2.insertEmail("[empty]", "[empty]", "test1", "[empty]");
    // test2.insertEmail("[empty]", "[empty]", "stest", "[empty]");
    // test2.insertEmail("[empty]", "[empty]", "test", "[empty]");
    // test2.DisplayInbox();
}
