#ifndef DBLLINKLIST_H
#define DBLLINKLIST_H

#include <iostream>
#include <iterator>
#include <list>
#include <string>

using namespace std;

template<typename T>
class Inbox
{
public:
    typedef list<T> Communication;//this is the communication node (doubly linked list)
    typedef typename list<T>::iterator CommunicationNode;//communication node iterator
    typedef list< list<T> > myInbox;//this is the communication node (doubly linked list)
    typedef typename list< list<T> >::iterator myInboxIter;//communication node iterato
    typedef list<T> Email;//email node
    typedef typename list<T>::iterator EmailNode;//email node iterator
    typedef list< list<T> > Correspondance;//this is the node that will store the communication nodes that contain the email nodes
    typedef typename list< list<T> >::iterator CorrespondanceNode;//this will iterate through the correspondance list


    void insertEmail(string to, string from, string subject, string message)
    {
        string newEmail = "To: " + to + " " + "\nFrom: " + from + "\n" +
                "Subject: " + subject + "\n" +message + "\n--------------";//combine the email into one string
        m_email.push_front(newEmail);//put the email into the linked list

        if(subjectExists(subject))//check if the subject already exists
        {
            m_comIter = searchCommunicatonNodes(subject);//if it exists, get a pointer to the node
//            m_communication.remove(subject);//remove it so that it can be placed at the front of the list
            m_comIter = m_communication.erase(m_comIter);//use the pointer to move the communication node to the front of the list
            m_myInbox.push_front(m_email);//add the email to myInbox
            m_communication.push_front(subject);//add the subject to the front of the communication node
            m_subjectNode.push_front(m_communication);//put the email at the front of the inbox
        }
        else
        {
            m_communication.push_front(subject);
            m_myInbox.push_front(m_email);
            m_subjectNode.push_front(m_communication);
        }

    }

//    void deleteCommNode(string subject)//Deletes a communication having a given subject.
//    {//TO DO: iterate through entire communication node and delete all corresponding emails
////first remove from the wrapper which contains the communications that store the email nodes
//        m_emailIter = searchMyInboxNodes(subject);
////now to remove from the communication from the doubly linked list communication node
//       int count = communicationSize(subject);
//       cout<<"Inside Comm Node:\n";
//       if(subjectExists(subject))
//       {
//           //get the size of the list containing the subject emails
//           m_comIter = searchCommunicatonNodes(subject);//get a pointer with the search communications node pointer
//           m_comIter =  m_communication.erase(m_comIter);
//        }

////now to remove the emails from doubly linked list email node

//        while(count != 0)
//        {
//            m_emailIter = searchEmailNodes(subject);
//            m_emailIter =  m_email.erase(m_emailIter);
//            count--;
//        }
//    }

    void DisplayInbox()//This will display Inbox by listing the communication in the order they appear in the Inbox from the most recent to the oldest, i.e., from beginning of doubly-linked list of communications, displaying the subject and the number of e-mails in the communication.
    {
        m_subjectNodeIterator = m_subjectNode.begin();//first iterate through main list
        //http://stackoverflow.com/questions/12280593/accessing-elements-of-a-list-of-lists-in-c

        m_myInboxIterator = m_myInbox.begin();

        cout << "Inbox:\n--------------\n" ;
        for(m_comIter = m_communication.begin(); m_comIter != m_communication.end(); m_comIter++)
        {
            string subj = *m_comIter;
            unsigned int count = communicationSize(subj);
            cout<<"Subject: " << *m_comIter << "--(" << count << ")\n";
            for(m_myInboxIterToEmailIterator = (*m_myInboxIterator).begin(); m_myInboxIterToEmailIterator != (*m_myInboxIterator).end(); m_myInboxIterToEmailIterator++)
            {
                string subjCheck = *m_myInboxIterToEmailIterator;
                if(subjCheck.find(subj) != string::npos)
                {
                    //this is the sanity check for printing the inbox
                    size_t found = subjCheck.find(subj);
                    if(subjCheck[found + (subj.length())] == '\n')
                        if( subjCheck[found-1] == ' ')
                            cout<< *m_myInboxIterToEmailIterator << "\n";
                }
            }
        }
    }

    bool subjectExists(string subject)
    {//a bool method for checking if a subject already has been created
        for(m_comIter = m_communication.begin(); m_comIter != m_communication.end(); m_comIter++)
            if(*m_comIter == subject)
            {
                return true;
            }
        return false;
    }

    unsigned int communicationSize(string subject)
    {//get the number of emails that relate to a specific subject
        unsigned int count = 0;

        m_myInboxIterator = m_myInbox.begin();


        for(m_myInboxIterToEmailIterator = (*m_myInboxIterator).begin(); m_myInboxIterToEmailIterator != (*m_myInboxIterator).end(); m_myInboxIterToEmailIterator++)
        {
            string subjCheck = *m_myInboxIterToEmailIterator;
            if(subjCheck.find(subject) != string::npos)
            {
//               //this is the sanity check for making sure we have the correct count
                size_t found = subjCheck.find(subject);
                if(subjCheck[found + (subject.length())] == '\n')
                    if( subjCheck[found-1] == ' ')
                        count++;
            }
        }
        return count;
    }

    void deleteCommNodes(string subject)
    {
//first remove from the wrapper which contains the communications that store the email nodes
        m_myInboxIterator = m_myInbox.begin();
        for(m_myInboxIterToEmailIterator = (*m_myInboxIterator).begin(); m_myInboxIterToEmailIterator != (*m_myInboxIterator).end(); m_myInboxIterToEmailIterator++)
        {
            string subjCheck = *m_myInboxIterToEmailIterator;
            if(subjCheck.find(subject) != string::npos)
                m_myInboxIterToEmailIterator =  (*m_myInboxIterator).erase(m_myInboxIterToEmailIterator);
        }
//now to remove from the communication from the doubly linked list communication node
        for(m_comIter = m_communication.begin(); m_comIter != m_communication.end(); m_comIter++)
        {
            string subj = *m_comIter;
            CommunicationNode temp = searchCommunicatonNodes(subj);//get a pointer with the search communications node pointer
            if(subj.find(subject) != string::npos)
                m_comIter =  m_communication.erase(temp);//this one uses the searchCommunicationsNodes method
//                m_comIter =  m_communication.erase(m_comIter);//this is sure to work, does not use the searchCommunicationsNodes method
        }

//now to remove the email from doubly linked list email node
        for(m_emailIter = m_email.begin(); m_emailIter != m_email.end(); m_emailIter++)
        {
            string subj = *m_emailIter;
            if(subj.find(subject) != string::npos)
                m_emailIter =  m_email.erase(m_emailIter);
        }

    }

    Communication m_communication;//this is the communication node for the inbox
    CommunicationNode m_comIter;//this is the main communication node iterator
    myInbox m_myInbox;
    myInboxIter m_myInboxIterator;
    EmailNode m_myInboxIterToEmailIterator;
    Email m_email;//this is the email node for the inbox
    EmailNode m_emailIter;//this is the email node iterator
    Correspondance m_subjectNode;//this contains the communication nodes that contain the emails
    CorrespondanceNode m_subjectNodeIterator;//this is the correspondance node iterator
    CommunicationNode m_correspondanceIterToCommunicationIter;//this is used to dereference nodes of the correspondance node since they are nodes within nodes

private:

    CommunicationNode searchCommunicatonNodes(string subject)//Searches the Inbox for a communication using subject as the key for the search. It returns a pointer to the communication node that matches the subject, or the null pointer if no such node is found.   This function should be private, and will be needed for both insertions and deletion.
    {
        for(m_comIter = m_communication.begin(); m_comIter != m_communication.end(); m_comIter++)
            if(*m_comIter == subject)
                return m_comIter;

        return CommunicationNode(NULL);
    }

    EmailNode searchEmailNodes(string subject)//Searches the Emails for an email with subject as the key for the search. It returns a pointer to the communication node that matches the subject, or the null pointer if no such node is found.   This function should be private, and will be needed for both insertions and deletion.
    {
        EmailNode pointer(NULL);
        for(m_emailIter = m_email.begin(); m_emailIter != m_email.end(); m_emailIter++)
        {
            string subj = *m_emailIter;
            if(subj.find(subject) != string::npos)
            {
                pointer = m_emailIter;
                return pointer;
            }
        }

        return pointer;
    }

    EmailNode searchMyInboxNodes(string subject)
    {
        m_myInboxIterator = m_myInbox.begin();
        EmailNode pointer;
        for(m_myInboxIterToEmailIterator = (*m_myInboxIterator).begin(); m_myInboxIterToEmailIterator != (*m_myInboxIterator).end(); m_myInboxIterToEmailIterator++)
        {
            string subjCheck = *m_myInboxIterToEmailIterator;
            if(subjCheck.find(subject) != string::npos)
                pointer = m_myInboxIterToEmailIterator;
        }

        return pointer;
    }

};

#endif // DBLLINKLIST_H
