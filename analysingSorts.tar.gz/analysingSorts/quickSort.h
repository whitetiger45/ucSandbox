#ifndef QUICKSORT_H
#define QUICKSORT_H

//https://gsamaras.wordpress.com/code/quicksort-c/

#include <vector>

#include "bubbleSort.h"
#include "insertionSort.h"

using namespace std;

int quickcomparisons = 0;
int tempquickcomparisons = 0;
/**
 * Swap the parameters.
 * @param a - The first parameter.
 * @param b - The second parameter.
*/
void swap(int & a, int & b)
{
    int temp = a;
    a = b;
    b = temp;
}

/**
 * Swap the parameters without a temp variable.
 * Warning! Prone to overflow/underflow.
 * @param a - The first parameter.
 * @param b - The second parameter.
*/
void swapNoTemp(int & a, int & b)
{
    a -= b;
    b += a;// b gets the original value of a
    a = (b - a);// a gets the original value of b
}

/**
 * Find and return the index of pivot element.
 * @param a - The array.
 * @param first - The start of the sequence.
 * @param last - The end of the sequence.
 * @return - the pivot element
*/
template<typename T>
int pivot(vector<T> & a, int first, int last, unsigned int threshold, string small)
{
    int p = first;
    int pivotElement = a[first];

    for(int i = first+1 ; i <= last ; i++)
    {

        /* If you want to sort the list in the other order, change "<=" to ">" */
        if((last - first) <= threshold)
        {
            if (small[0] == 'b')
            {
//                cout << "(Using bubble sort algorithm...)\n";
                bubbleSort(a);
            }
            else if(small[0] == 'i' || small[0] == 'I')
            {
//                cout << "(Using insertion sort algorithm...)\n";
                insertionSort(a);
            }
            break;
        }

        if(a[i] <= pivotElement)
        {
            p++;
            swap(a[i], a[p]);
        }
        quickcomparisons++;
    }

    swap(a[p], a[first]);

    return p;
}


/**
 * Quicksort.
 * @param a - The array to be sorted.
 * @param first - The start of the sequence to be sorted.
 * @param last - The end of the sequence to be sorted.
*/
template<typename T>
void quickSort( vector<T> & a, int first, int last)
{
    int pivotElement = 0;

    if(first < last)
    {
        pivotElement = pivot(a, first, last);
        quickSort(a, first, pivotElement-1);
        quickSort(a, pivotElement+1, last);
    }
}

//overloaded function
template<typename T>
void quickSort( vector<T> & a, int first, int last, unsigned int threshold, string small)
{
    int pivotElement = 0;

    if(first < last)
    {
        pivotElement = pivot(a, first, last, threshold, small);
        quickSort(a, first, pivotElement-1, threshold, small);
        quickSort(a, pivotElement+1, last, threshold, small);
    }
}

void displayQuickComparisons()
{
    cout << "Comparisons inside quicksort: " << quickcomparisons << endl;
}


int getQuickComparisons()
{
    return quickcomparisons;
}

void resetQuickComparisons()
{
    quickcomparisons = 0;
}

int valQuickComparisons(){
    tempquickcomparisons = quickcomparisons;
    quickcomparisons = 0;         // Resets insertcomparisons for the next analysis loop
    return tempquickcomparisons;  // Return the value
}

#endif // QUICKSORT_H
