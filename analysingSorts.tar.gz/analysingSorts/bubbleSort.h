#ifndef BUBBLESORT_H
#define BUBBLESORT_H

#include <string>
#include <vector>

//www.algolist.net/Algorithms/Sorting/Bubble_sort

using namespace std;

int bubblecomparisons = 0;
int tempbubblecomparisons = 0;

template<typename T>
void bubbleSort(vector <T> & array)
{
    bool swapped = true;
    int j = 0;
    int tmp;

    while (swapped)
    {
        swapped = false;
        j++;

        for (int i = 0; i < array.size() - j; i++)
        {
            if (array[i] > array[i + 1])
            {
                tmp = array[i];
                array[i] = array[i + 1];
                array[i + 1] = tmp;
                swapped = true;
            }
            bubblecomparisons++;
        }
    }

}

void displayBubbleComparisons()
{
    cout << "Comparisons inside bubble sort: " << bubblecomparisons << "\n";
}

int getBubbleComparisons()
{
    return bubblecomparisons;
}

void resetBubbleComparisons()
{
    bubblecomparisons = 0;
}

int  valBubbleComparisons(){
    tempbubblecomparisons = bubblecomparisons;
    //cout << "tempbubbles before reset: " << tempbubblecomparisons << endl;
    bubblecomparisons = 0;         // Resets bubblecomparisons for the next analysis loop
    return tempbubblecomparisons;  // Return the value
}

#endif // BUBBLESORT_H
