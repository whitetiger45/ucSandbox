#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H

#include <string>
#include <vector>
using namespace std;

//http://mathbits.com/MathBits/CompSci/Arrays/Insertion.htm

int insertcomparisons = 0;
int tempinsertcomparisons = 0;

template<typename T>
void insertionSort(vector <T> & arr)
{
  int j, temp, length = arr.size();
  for (int i = 1; i < length; i++){
    j = i;

    while (j > 0 && arr[j] < arr[j-1]){
        temp = arr[j];
        arr[j] = arr[j-1];
        arr[j-1] = temp;
        j--;
        insertcomparisons++;
        }
    }
}

void displayInsertComparisons()
{
    cout << "Comparisons inside insertion sort: " << insertcomparisons << "\n";
}

int getInsertComparisons()
{
    return insertcomparisons;
}

void resetInsertComparisons()
{
    insertcomparisons = 0;
}

int valInsertComparisons(){
    tempinsertcomparisons = insertcomparisons;
    insertcomparisons = 0;         // Resets insertcomparisons for the next analysis loop
    return tempinsertcomparisons;  // Return the value
}

#endif // INSERTIONSORT_H
