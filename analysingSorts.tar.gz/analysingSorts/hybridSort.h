#ifndef HYBRIDSORT_H
#define HYBRIDSORT_H

#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

#include "mArray.h"

using namespace std;

template<typename T>
void hybridSort(Array<T> & array, string large, string small, unsigned int threshold, bool displayComparisons)
{
    if(array.Size() > threshold)
    {
        if(large[0] == 'M' || large[0] == 'm')
        {
            //cout << "\n(Using MergeSort algorithm to sort your list...)";
            array.mSort(threshold, small);

            if(displayComparisons)
                array.displayComparisons(large, small);
        }
        else if(large[0] == 'Q' || large[0] == 'q')
        {
            //cout << "\n(Using QuickSort algorithm to sort your list...)";

            array.qSort(threshold, small);
            if(displayComparisons)
                array.displayComparisons(large, small);
        }
    }
    else
    {
        if(small[0] == 'B' || small[0] == 'b')
        {
            //cout << "\n(Using BubbleSort algorithm to sort your list...)";
            array.bSort();
            if(displayComparisons)
                array.displayComparisons(small);
        }
        else if(small[0] == 'I' || small[0] == 'i')
        {
            //cout << "\n(Using InsertionSort algorithm to sort your list...)";
            array.iSort();
            if(displayComparisons)
                array.displayComparisons(small);
        }
    }
}

#endif // HYBRIDSORT_H