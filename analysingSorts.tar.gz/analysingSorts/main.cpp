/*
 *Author: Bryan Kanu, Dan Wendelken, Jed Lantikus
 *Course title: Data Structures
 *Course number: CS2028
 *Instructor: Anca Ralescu
 *TA: Suryadip Chakraborty
 *Abstract: The theme of Assignment 4 is the analysis of four different sorting algorithms
 *to determine the run-times for each algorithm to test their efficiency
 */

#include <iostream>
#include <time.h>
#include <vector>
#include <string>
#include <sstream>

#include "hybridSort.h"

using namespace std;

Array<int> generateRandArray(int SIZE){
    Array<int> temp;
    
    for (int j = 0; j < SIZE; j++)
    {
        temp.pushBack(rand() % 100);
    }
    return temp;
}

int main()
{

    srand(time(NULL)); // Seeds the generateRandArray function so that in the for loop it is new arrays

    //Here is where we will begin to implement the menu
    cout << "\n---------------------------------------------------------------------------------------------------------------------------------\n";
    cout << "\nDescription:\n------------\n\nThis program will allow you to determine the most efficient\nsorting algorithm";
    cout << " depending on the amount of data to be sorted.\n\nAlgorithms:\n-----------\n\nBubble Sort\nHybrid Sort\nInsertion Sort\nMerge Sort";
    cout << " \nQuick Sort\n\nHybrid Sort:\n------------\n\n";
    cout << "Combines the algorithms of Quick Sort and\nMerge Sort with Bubble Sort and Insertion Sort.\n\nHelp:\n-----\n\nThe algorithms to be used ";
    cout << "are decided by the user.";
    cout << " The user must also\ndeclare a threshold value to be used to determine the\ncut off so that once this threshold value";
    cout << " is reached, the small list\nsorting algorithm can be used. While the list size exceeds\nthe threshold value the large sorting";
    cout << " algorithm will be used to sort\nthe elements of the list.\n\nFor lists smaller than 101 elements, the user will have the option\nto";
    cout << " manually enter the elements to be sorted.\nFor list sizes equal to and greater than 101 elements, a random list\nwill be generated";
    cout << " for the user of the desired list size.\n\nThe user will be able to choose to display the number of comparisons\nused by each sorting";
    cout << " algorithm used to sort the lists.\n\nThe user has the option to display the list they have entered.\nBoth the sorted and unsorted";
    cout << " versions of the list will be displayed. ";
    cout << "\n---------------------------------------------------------------------------------------------------------------------------------\n" << endl;
    
    Array<int> myArray;
    while(true){

    ///////////////////////////////////////////////////////////////
    ///////         Variables for analysis                  ///////
    ///////////////////////////////////////////////////////////////

    int listN = 0; // number of lists to analyze
    

    int tempBubble = 0;
    int maxBubble = 0;
    int minBubble = 0;
    int averageBubble = 0;
    int tempAvgB = 0;       // A temporary variable that will equal the sum of the Nsorts. The average will equal tempAvg / listN

    int tempInsert = 0;
    int maxInsert = 0;
    int minInsert = 0;
    int averageInsert = 0;
    int tempAvgI = 0;

    int tempMB = 0;
    int maxMergeBubble = 0;
    int minMergeBubble = 0;
    int averageMergeBubble = 0;
    int tempAvgMB = 0;

    int tempMI = 0;
    int maxMergeInsert = 0;
    int minMergeInsert = 0;
    int averageMergeInsert = 0;
    int tempAvgMI = 0;

    int tempQB = 0;
    int maxQuickBubble = 0;
    int minQuickBubble = 0;
    int averageQuickBubble = 0;
    int tempAvgQB = 0;

    int tempQI = 0;
    int maxQuickInsert = 0;
    int minQuickInsert = 0;
    int averageQuickInsert = 0;
    int tempAvgQI = 0;


    ///////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////
        int threshold = 0;
        int listSize = 0;
        bool displayList = true;
        bool displayComparisons = true;
        string decision = "";

        string line;
        cout << "Enter the threshold value: " <<endl;
        while (getline(cin, line))
        {
            //cout << "Line= " << line << endl; 
            stringstream ss(line);
            if (ss >> threshold)
            {
                if (ss.eof())
                {   // Success
                    break;
                }
            }
            if (line!=""){
                cout << "Input numbers only!" << endl;
            }
        }

        cout << "Enter the desired list size: \n";
        while (getline(cin, line))
        {
            stringstream ss(line);
            if (ss >> listSize)
            {
                if (ss.eof())
                {   // Success
                    break;
                }
            }
            if (line!=""){
                cout << "Input numbers only!" << endl;
            }
        }

        if(!(listSize > 100)){
            cout << "Manually enter list (randomly generated otherwize)? (y/n): ";
            decision = "";
            while(true){
                cin >> decision;
                if (decision == "y" || decision =="n"){
                    if(decision == "n"){
                        myArray = generateRandArray(listSize);
                        break;
                    }else{
                        cout << "Input int list (press enter after each int): " << endl;
                        for (int j = 0; j < listSize; j++)
                        {
                            int temp = 0;
                            while (getline(cin, line))
                            {
                                stringstream ss(line);
                                if (ss >> temp)
                                {
                                    if (ss.eof())
                                    {   // Success
                                        myArray.pushBack(temp);
                                        break;
                                    }
                                }
                                if (line!=""){
                                    cout << "Input numbers only!" << endl;
                                }
                            }
                        }
                        break;
                    }

                }else{
                    cout << "Please use either (y/n):" << endl;
                }
            }

            //Display list
            cout << "Display List? (y/n): ";
            decision = "";
            while(true){
                cin >> decision;
                if (decision == "y" || decision =="n"){
                    if(decision == "n"){
                        displayList = false;
                        break;
                    }else{
                        break;
                    }

                }else{
                    cout << "Please use either (y/n):" << endl;
                }
            }

            //Display Comparisons
            cout << "Display comparison count? (y/n): ";
            decision = "";
            while(true){
                cin >> decision;
                if (decision == "y" || decision =="n"){
                    if(decision == "n"){
                        displayComparisons = false;
                        break;
                    }else{
                        break;
                    }

                }else{
                    cout << "Please use either (y/n):" << endl;
                }
            }
        }else{
            myArray = generateRandArray(listSize);
            displayList = false;
            //Display Comparisons
            cout << "Display comparison count? (y/n): ";
            decision = "";
            while(true){
                cin >> decision;
                if (decision == "y" || decision =="n"){
                    if(decision == "n"){
                        displayComparisons = false;
                        break;
                    }else{
                        break;
                    }

                }else{
                    cout << "Please use either (y/n):" << endl;
                }
            }
        }

        if(displayList || displayComparisons){
            cout << "=================================================" << endl;
        }

        //Bubble sort
        Array<int> temp = myArray;
        if(displayList){
            cout << "+++++++++++++++++++++++++++++++++++++++++++++++++" << endl;
            cout << endl << "Before BubbleSort: " << endl;
            myArray.print();
        }
        myArray.bSort();

        if(displayComparisons){
            cout << "------Bubble Sort Only------" << endl;
            displayBubbleComparisons(); 
        }

        if(displayList){
            cout << "After BubbleSort: " << endl;
            myArray.print();
        }

        resetBubbleComparisons(); //reset the bubble comparisons

        //Insertion sort
        myArray = temp;
        if(displayList){
            cout << "+++++++++++++++++++++++++++++++++++++++++++++++++\n";
            cout << "Before InsertionSort: " << endl;
            myArray.print();
        }
        myArray.iSort();
        if(displayComparisons){
            cout << endl <<"------Insertion Sort Only------" << endl;
            displayInsertComparisons(); 
        }

        if(displayList){
            cout << "After InsertionSort: " << endl;
            myArray.print();
        }

        resetInsertComparisons(); //reset the insert comparisons

        //Merge w/ Bubble sort
        myArray = temp;
        if(displayList){
            cout << "+++++++++++++++++++++++++++++++++++++++++++++++++\n";
            cout << "Before Merge w/ Bubble: " << endl;
            myArray.print();
        }

        if(displayComparisons){
            cout << endl <<"------Merge w/ Bubble------" << endl;
        }
        hybridSort(myArray, "mergesort", "bubblesort", threshold, displayComparisons);

        if(displayList){
            cout << "After Merge w/ Bubble: " << endl;
            myArray.print();
        }

        resetBubbleComparisons(); //reset the bubble comparisons
        resetMergeComparisons(); // reset merge sort

        //Merge w/ Insertion sort
        myArray = temp;
        if(displayList){
            cout << "+++++++++++++++++++++++++++++++++++++++++++++++++\n";
            cout << "Before Merge w/ InsertionSort: " << endl;
            myArray.print();
        }

        if(displayComparisons){
            cout << endl <<"------Merge w/ Insertion------" << endl;
        }
        hybridSort(myArray, "mergesort", "insertionsort", threshold, displayComparisons);

        if(displayList){
            cout << "After Merge w/ InsertionSort: " << endl;
            myArray.print();
        }

        resetMergeComparisons();
        resetInsertComparisons(); 

        //quicksort w/ bubble sort
        myArray = temp;
        if(displayList){
            cout << "+++++++++++++++++++++++++++++++++++++++++++++++++\n";
            cout << "Before Quick w/ Bubble: " << endl;
            myArray.print();
        }

        if(displayComparisons){
            cout << endl <<"------Quick w/ Bubble------" << endl;
        }
        hybridSort(myArray, "quicksort", "bubblesort", threshold, displayComparisons);

        if(displayList){
            cout << "After Quick w/ Bubble: " << endl;
            myArray.print();
        }

        resetQuickComparisons();
        resetBubbleComparisons(); //reset the bubble comparisons

        //quicksort w/ insertion sort
        myArray = temp;
        if(displayList){
            cout << "+++++++++++++++++++++++++++++++++++++++++++++++++\n";
            cout << "Before Quick w/ InsertionSort: " << endl;
            myArray.print();
        }

        if(displayComparisons){
            cout << endl <<"------Quick w/ Insertion------" << endl;
        }
        hybridSort(myArray, "quicksort", "insertionsort", threshold, displayComparisons);

        if(displayList){
            cout << "After Quick w/ InsertionSort: " << endl;
            myArray.print();
        }

        resetQuickComparisons();
        resetInsertComparisons(); 

        cout << "=====================Done========================" << endl;


        /////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////
        /////////////   This portion is used to calculate the average, max,    //////////
        /////////////   and min for N lists.                                   //////////
        /////////////////////////////////////////////////////////////////////////////////

        cout << "\nEnter the N number of lists you want to perform analysis on." << endl;
        cin >> listN;
/*
        valBubbleComparisons();
        valInsertComparisons();
        valMergeComparison();
        valQuickComparisons();
*/
        bool firstMin = 0; 

        for (int i = 1; i <= listN; i++){

            /////////////////////////////////////////////////////////////////////////////
            /////////// Bubble analysis         /////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////

            myArray.eraseAll();
            myArray = generateRandArray(listSize);      // Each time the loop starts, a new random list will be created.
            //myArray.print();
            temp = myArray;                             // temp is the random list that will be used to compare all the algorithms.
            myArray.bSort();

            //displayBubbleComparisons();
            tempBubble = valBubbleComparisons();
            //cout << "tempAvgB: " << tempAvgB << "tempBubble: " << tempBubble << endl;
            tempAvgB = tempAvgB + tempBubble;

            //cout << "tempBubble: " << tempBubble << endl; 
            if(tempBubble > maxBubble){
                maxBubble = tempBubble;
            }

            if(firstMin == 0){
                minBubble = tempBubble;
                //firstMin = 1;
            }

            if (tempBubble < minBubble){
                minBubble = tempBubble;
            }

            /////////////////////////////////////////////////////////////////////////////
            /////////// Insert analysis         /////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////
            
            myArray = temp;         ////// Use the same unsorted array that we sorted with bubble
            myArray.iSort();
            tempInsert = valInsertComparisons();
            tempAvgI = tempAvgI + tempInsert;

            if(tempInsert > maxInsert){
                maxInsert = tempInsert;
            }

            if(firstMin == 0){
                minInsert = tempInsert;
                //firstMin = 1;
            }

            if (tempInsert < minInsert){
                minInsert = tempInsert;
            }
            

            /////////////////////////////////////////////////////////////////////////////
            /////////// Merge Bubble analysis         ///////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////

            myArray = temp;         ////// Use the same unsorted array that we sorted with bubble
            hybridSort(myArray, "mergesort", "bubblesort", threshold, 0);
            tempMB = valMergeComparison() + valBubbleComparisons();
            tempAvgMB = tempAvgMB + tempMB;

            if(tempMB > maxMergeBubble){
                maxMergeBubble = tempMB;
            }

            if(firstMin == 0){
                minMergeBubble = tempMB;
                //firstMin = 1;
            }

            if (tempMB < minMergeBubble){
                minMergeBubble = tempMB;
            }
            
            /////////////////////////////////////////////////////////////////////////////
            /////////// Merge Insert analysis         ///////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////

            myArray = temp;         ////// Use the same unsorted array that we sorted with bubble
            hybridSort(myArray, "mergesort", "insertsort", threshold, 0);
            tempMI = valMergeComparison() + valInsertComparisons();
            //cout << " merge comp: " << valMergeComparison() << "insert comp: " << valInsertComparisons() << endl;
            tempAvgMI = tempAvgMI + tempMI;

            if(tempMI > maxMergeInsert){
                maxMergeInsert = tempMI;
            }

            if(firstMin == 0){
                minMergeInsert = tempMI;
                //firstMin = 1;
            }

            if (tempMI < minMergeInsert){
                minMergeInsert = tempMI;
            }

            /////////////////////////////////////////////////////////////////////////////
            /////////// Quick Bubble analysis         ///////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////

            myArray = temp;         ////// Use the same unsorted array that we sorted with bubble
            hybridSort(myArray, "quicksort", "bubblesort", threshold, 0);
            tempQB = valQuickComparisons() + valBubbleComparisons();
            tempAvgQB = tempAvgQB + tempQB;

            if(tempQB > maxQuickBubble){
                maxQuickBubble = tempQB;
            }

            if(firstMin == 0){
                minQuickBubble = tempQB;
                //firstMin = 1;
            }

            if (tempQB < minQuickBubble){
                minQuickBubble = tempQB;
            }

            /////////////////////////////////////////////////////////////////////////////
            /////////// Quick Insert analysis         ///////////////////////////////////
            /////////////////////////////////////////////////////////////////////////////

            myArray = temp;         ////// Use the same unsorted array that we sorted with bubble
            hybridSort(myArray, "quicksort", "insertsort", threshold, 0);
            tempQI = valQuickComparisons() + valInsertComparisons();
            tempAvgQI = tempAvgQI + tempQI;

            if(tempQI > maxQuickInsert){
                maxQuickInsert = tempQI;
            }

            if(firstMin == 0){
                minQuickInsert = tempQI;
                firstMin = 1;
            }

            if (tempQI < minQuickInsert){
                minQuickInsert = tempQI;
            }
        }

        cout << "Average Bubble: " << (tempAvgB / listN) << endl;
        cout << "Min Bubble: " << minBubble << endl;
        cout << "Max Bubble: " << maxBubble << endl;

        cout << "Average Insert: " << (tempAvgI / listN) << endl;
        cout << "Min Insert: " << minInsert << endl;
        cout << "Max Insert: " << maxInsert << endl;

        cout << "Average Merge / Bubble: " << (tempAvgMB / listN) << endl;
        cout << "Min Merge / Bubble: " << minMergeBubble << endl;
        cout << "Max Merge / Bubble: " << maxMergeBubble << endl;

        cout << "Average Merge / Insert: " << (tempAvgMI / listN) << endl;
        cout << "Min Merge / Insert: " << minMergeInsert << endl;
        cout << "Max Merge / Insert: " << maxMergeInsert << endl;

        cout << "Average Quick / Bubble " << (tempAvgQB / listN) << endl;
        cout << "Min Quick / Bubble: " << minQuickBubble << endl;
        cout << "Max Quick / Bubble: " << maxQuickBubble << endl;

        cout << "Average Quick / Insert " << (tempAvgQI / listN) << endl;
        cout << "Min Quick / Insert: " << minQuickInsert << endl;
        cout << "Max Quick / Insert: " << maxQuickInsert << endl;

        //Repeat process?
        decision = "";
        cout << "\n Would you like to repeat process? (y/n)" << endl;
        while(true){
            cin >> decision;
            if (decision == "y" || decision =="n"){
                if(decision == "n"){
                    return 0;
                }else{
                    myArray.eraseAll();
                    break;
                }

            }else{
                cout << "Please use either (y/n):" << endl;
            }
        }


        



    //call to hybrid sort is as the following:
    // hybridSort(<list name>, <large sorting algorithm>, <small sorting algorithm>, <threshold value>, <display comparisons>)





        //hybridSort(test, "quicksort", "bubblesort", 3, true);

       // hybridSort(test, "quicksort", "insertionsort", 8, true);//
    //    hybridSort(test, "quicksort", "insertionsort", 8, false);
    //    hybridSort(test, "mergesort", "bubblesort", 3, true);
    //    hybridSort(test, "mergesort", "insertionsort", 16, true);

    //    cout << endl << endl << "After sorting : " << endl;
    //    test.print();
    }



    

    return 0;
}
