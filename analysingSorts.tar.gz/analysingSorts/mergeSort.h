#ifndef MERGESORT_H
#define MERGESORT_H

#include <string>
#include <vector>

#include "bubbleSort.h"
#include "insertionSort.h"

using namespace std;

int mergecomparisons = 0;
int tempmergecomparisons = 0;

typedef vector<int> array;

template <class T>
void mergev(vector<T> & l, vector<T> & r, vector<T> & s)
{

    unsigned int li = 0;
    unsigned int ri = 0;

    while(li < l.size() || ri < r.size())
    {
        if(li == l.size())
        {
            s.push_back(r[ri]);
            ri++;
        }
        else if(ri == r.size())
        {
            s.push_back(l[li]);
            li++;
        }
        else if(l[li] < r[ri])
        {//if left is smaller than right, pushback left
            s.push_back(l[li]);
            li++;
            mergecomparisons++;
        }
        else
        {//or else push back the right side if it's smaller than the left
            s.push_back(r[ri]);
            ri++;
            mergecomparisons++;
        }
    }

//    if(displayComparisons)
//        cout << "Comparisons inside merge sort: " << comparisons << "\n";
}

void mergeSort( array & A, unsigned int threshold, string small)
{

    if(A.size() <= 1)
        return ;

    if(A.size() <= threshold)
    {
        if(small[0] == 'b' || small[0] == 'B')
            bubbleSort(A);
        else if(small[0] == 'i' || small[0] == 'I')
            insertionSort(A);
    }
    int split = A.size() / 2;

    array left;
    array right;
    for(unsigned int i = 0; i < A.size(); i++)
    {
        if(i < split)
        {
            left.push_back(A[i]);
        }
        else right.push_back(A[i]);
    }

    mergeSort(left, threshold, small);//recursive call to merge sort for left side
    mergeSort(right, threshold, small);//recursive call to merge for right side

    A.clear();
    mergev(left, right, A);//call merge on the sorted left and right vectors

}

void displayMergeComparisons()
{
    cout << "Comparisons inside merge sort: " << mergecomparisons << endl;
}

int getMergeComparisons()
{
    return mergecomparisons;
}

void resetMergeComparisons()
{
    mergecomparisons = 0;
}

int valMergeComparison() {
    tempmergecomparisons = mergecomparisons;
    mergecomparisons = 0;                       // Resets insertcomparisons for the next analysis loop
    return tempmergecomparisons;                // Return the value
}
//void merge(array & l, array & r, array & A)
//{

//    unsigned int li = 0;
//    unsigned int ri = 0;

//    while(li < l.size() || ri < r.size())
//    {
//        if(li == l.size())
//        {
//            A.push_back(r[ri]);
//            ri++;
//        }
//        else if(ri == r.size())
//        {
//            A.push_back(l[li]);
//            li++;
//        }
//        else if(l[li] < r[ri])
//        {//if left if smaller than right, pushback left
//            A.push_back(l[li]);
//            li++;
//        }
//        else
//        {//or else push back the right side if it's smaller than the left
//            A.push_back(r[ri]);
//            ri++;
//        }

//    }

//}

//void merge_sort(array & numbers)
//{
//    if(numbers.size() <= 1)
//        return;

//    unsigned int split = numbers.size() / 2;

//    array left;
//    array right;

//    for(unsigned int i = 0; i < numbers.size(); i++)
//    {
//        if(i < split)
//        {
//            left.push_back(numbers[i]);
//        }
//        else right.push_back(numbers[i]);
//    }

//    merge_sort(left);//recursive call to merge sort for left side
//    merge_sort(right);//recursive call to merge for right side

//    numbers.clear();
//    merge(left, right, numbers);//call merge on the sorted left and right vectors

//}

#endif // MERGESORT_H
