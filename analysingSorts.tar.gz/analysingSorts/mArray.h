#ifndef MARRAY_HXX
#define MARRAY_HXX

#include <algorithm>
#include <string>
#include <vector>

#include "bubbleSort.h"
#include "insertionSort.h"
#include "insertionSort.h"
#include "mergeSort.h"
#include "quickSort.h"

using namespace std;

template <typename T>
struct Array
{
    typedef vector<T> A;//this is an array

    void pushBack(T value)//add an element to the array
    {
        m_Array.push_back(value);
    }

    A array() //get the entire array for use with the different sort functions
    {
        return m_Array;
    }

    int Size()
    {
        return m_Array.size();
    }

    void print()//print out the entire array
    {
        cout << "----------------\n";
        for( int i = m_Array.size()-1; i >= 0; i--)
        {
            cout << i+1 <<") " << m_Array[i] << "\n";
        }
        //cout << "-----------------\n";
        cout << endl;
    }

    void eraseAll()//clear out the entire array
    {
        m_Array.clear();
    }

    void popBack()//remove the last element of the array
    {
        m_Array.pop_back();
    }

    void stdSort()
    {
        std::sort(m_Array.begin(), m_Array.end());
    }

    void iSort()//insertion sort
    {
        insertionSort(m_Array);
    }

    void mSort(unsigned int threshold, string small)
    {
        mergeSort(m_Array, threshold, small);
    }

    void bSort()
    {
        bubbleSort(m_Array);
    }

    void qSort()
    {
        quickSort(m_Array, 0, m_Array.size());
    }

    void qSort(unsigned int threshold, string small)//if given a threshold and a small sorting algorithm to use
    {
        quickSort(m_Array, 0, m_Array.size(), threshold, small);
    }

    void displayComparisons(string large, string small)
    {
        if(large[0] == 'M' || large[0] == 'm')
            displayMergeComparisons();
        else if(large[0] == 'Q' || large[0] == 'q')
            displayQuickComparisons();

        if(small[0] == 'B' || small[0] == 'b')
            displayBubbleComparisons();
        else if(small[0] == 'I' || small[0] == 'i')
            displayInsertComparisons();
    }

    void displayComparisons(string small)
    {
        if(small[0] == 'B' || small[0] == 'b')
            displayBubbleComparisons();
        else if(small[0] == 'I' || small[0] == 'i')
            displayInsertComparisons();
    }
//new methods to get and reset comparisons which can be added to an array
    /*int getBubbleComparisons()
    {
        return getBubbleComparisons();
    }

    int getInsertComparisons()
    {
        return getInsertComparisons();
    }

    int getMergeComparisons()
    {
        return getMergeComparisons();
    }

    int getQuickComparisons()
    {
        return getQuickComparisons();
    }

    void resetComparisons()
    {
        resetBubbleComparisons();
        resetInsertComparisons();
        resetMergeComparisons();
        resetQuickComparisons();
    }*/

    A m_Array;
//    static const string m_resultAsString[2];
};

#endif // MARRAY_HXX
