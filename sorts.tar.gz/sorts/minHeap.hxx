#ifndef MINHEAP_HXX
#define MINHEAP_HXX

//@description Implements a templated minimum queue, using a
//heap structure.
//http://www.algolist.net/Data_structures/Binary_heap/Remove_minimum
//http://www.algolist.net/Data_structures/Binary_heap/Insertion
//http://www.algolist.net/Data_structures/Binary_heap/Array-based_int_repr

#include <iostream>
#include <stdexcept>
#include <vector>

using namespace std;

template <class T>
class MinHeap
{
    public:

        MinHeap()
            : heap_size(0)
        {
        }

        ~MinHeap(){}

        void bubble_up(unsigned node_index)
        {
            unsigned int get_parent_index;
            T temp;
            if(node_index != 0){
                get_parent_index = parent_index(node_index);
                if(data[get_parent_index] > data[node_index]){
                    temp = data[get_parent_index];
                    data[get_parent_index] = data[node_index];
                    data[node_index] = temp;
                    bubble_up(get_parent_index);
                }
            }
        }
        void push(T value)
        {
            if(data.size() == 0)
            {
                data.push_back(value);
                heap_size++;
            }
            else
            {
                heap_size++;
                it = data.end();
                it = data.insert(it, value);
                bubble_up(heap_size-1);
            }
        }

        void bubble_down(unsigned int node_index)
        {
            unsigned int get_left_index, get_right_index, min_index;
            T temp;

            get_left_index = left_index(node_index);
            get_right_index = right_index(node_index);

            if(get_right_index >= heap_size)
            {
                if(get_left_index >= heap_size)
                    return;
                else
                    min_index = get_left_index;
            }
            else
            {
                if(data[get_left_index] <= data[get_right_index])
                    min_index = get_left_index;
                else
                    min_index = get_right_index;
            }
            if(data[node_index] > data[min_index])
            {
                temp = data[min_index];
                data[min_index] = data[node_index];
                data[node_index] = temp;
                bubble_down(min_index);
            }
        }

        void pop()
        {
            if(heap_size == 0)
                return;
            else{
                data[0] = data[heap_size-1];
                heap_size--;
                if(heap_size > 0)
                    bubble_down(0);
            }
        }

        T top()
        {
            if(heap_size == 0)
                throw logic_error("Heap is empty!");
            else
                return data[0];
        }

        unsigned int size()
        {
            if(heap_size == 0)
                throw logic_error("Heap is empty!");
            else
                return heap_size;
        }

        void print_data()
        {
            while(heap_size != 0)
            {
                cout<< top() << endl;
                pop();
            }
        }

        unsigned int array_size;
        vector<T> data;
    private:

        unsigned int heap_size;

        typename vector<T>::iterator it;

        unsigned int left_index(unsigned int node_index)
        {
            return 2 * node_index + 1;
        }

        unsigned int right_index(unsigned int node_index)
        {
            return 2 * node_index + 2;
        }

        unsigned int parent_index(unsigned int node_index)
        {
            return (node_index-1)/2;
        }

};

#endif // MINHEAP_HXX
