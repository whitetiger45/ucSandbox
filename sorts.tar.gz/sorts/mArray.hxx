#ifndef MARRAY_HXX
#define MARRAY_HXX

#include <algorithm>
#include <string>
#include <vector>

#include "insertionSort.hxx"
#include "isUnique.hxx"
#include "insertionSort.hxx"
#include "mergeSort.hxx"
#include "minHeap.hxx"

using namespace std;

template <typename T>
struct Array
{
    typedef vector<T> A;//this is an array

    void pushBack(T value)//add an element to the array
    {
        m_Array.push_back(value);
    }

    A array() //get the entire array for use with the different sort functions
    {
        return m_Array;
    }

    int Size()
    {
        return m_Array.size();
    }

    void print()//print out the entire array
    {
        cout << "Printing Array:\n-----------------\n";
        for( int i = m_Array.size()-1; i >= 0; i--)
        {
            cout << i+1 <<") " << m_Array[i] << "\n";
        }
        cout << "-----------------\nEnd of Array.\n";
    }

    void eraseAll()//clear out the entire array
    {
        m_Array.clear();
    }

    void popBack()//remove the last element of the array
    {
        m_Array.pop_back();
    }

    void stdSort()//insertion sort
    {
        std::sort(m_Array.begin(), m_Array.end());
    }

    void iSort()//insertion sort
    {
        insertionSort(m_Array);
    }

    void mSort()
    {
        mergeSort(m_Array);
    }

    typedef bool (*checkUnique)(A, unsigned int, unsigned int); // function pointer for checking that the array is unique

    void checkArrayUniqueness(checkUnique func, unsigned int first, unsigned int last)
    {
        m_Unique = func(m_Array, first, last);

    }

    A m_Array;
    bool m_Unique;
//    static const string m_resultAsString[2];
};

#endif // MARRAY_HXX
