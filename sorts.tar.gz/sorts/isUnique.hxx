#ifndef ISUNIQUE_HXX
#define ISUNIQUE_HXX

#include <vector>

#include "mArray.hxx"
#include "minHeap.hxx"

using namespace std;

//typedef vector<int> array;//typedef for a vector is called an array
template<typename T>
bool isUnique1( vector<T> A, unsigned int first, unsigned int last )
{
//Input: Array A, first, last
//Output:
//true if the array contains no repeated elements
//false if the array contains repeated elements
    if (first >= last)
        return true;

    if (!isUnique1(A, first, last-1))
        return false;

    if (!isUnique1(A, first+1, last))
        return false;

    return(A[first]!=A[last]);
}

template<typename T>
bool isUnique2( vector<T> A, unsigned int first, unsigned int last)
{
//   Input: Array A, first, last
//   Output:
//true if the array contains no repeated elements
//false if the array contains repeated elements
    if (first >= last)
        return true;

    for (unsigned int i =  first; i < last; i++)
    {
        for (unsigned int j = i+1; j <= last; j++)
        {
            if (A[i] == A[j])
            {
                return false;
            }
        }
    }
    return true;
}

template<typename T>
bool isUnique3M( Array<T> A, unsigned int first, unsigned int last)//isUnique3 with Merge Sort
{
//   Input: Array A, first, last
//   Output:
//true if the array contains no repeated elements
//false if the array contains repeated elements
    if (first >= last)
        return true;

    A.mSort();

    for (int i =  first; i < last; i++)
    {
        if (A[i] == A[i+1])
        {
            return false;
        }
    }
    return true;
}

template<typename T>
bool isUnique3I( Array<T> A, unsigned int first, unsigned int last)//isUnique3 with Insertion Sort
{
//   Input: Array A, first, last
//   Output:
//true if the array contains no repeated elements
//false if the array contains repeated elements
    if (first >= last)
        return true;

    A.iSort();

    for (int i =  first; i < last; i++)
    {
        if (A[i] == A[i+1])
        {
            return false;
        }
    }
    return true;
}

template<typename T>
bool isUnique3MH( MinHeap<T> A, unsigned int first, unsigned int last)//isUnique3 with MinHeap Sort
{
//   Input: Array A, first, last
//   Output:
//true if the array contains no repeated elements
//false if the array contains repeated elements
    if (first >= last)
        return true;

    for (int i =  first; i < last; i++)
    {
        if (A.data[i] == A.data[i+1])
        {
            return false;
        }
    }
    return true;
}

#endif // ISUNIQUE_HXX
