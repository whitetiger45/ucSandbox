/*
 *Author: Bryan Kanu, Dan Wendelken, Jed Lantikus
 *Course title: Data Structures
 *Course number: CS2028
 *Instructor: Anca Ralescu
 *TA: Suryadip Chakraborty
 *Abstract: Assignment 2 main.cxx uses the three different sorting algorithms
 *to determine the run-times for each approach to test their efficiency
 */

#include <iostream>
#include <string>
#include <vector>

#include "isUnique.hxx"
#include "mArray.hxx"
#include "minHeap.hxx"

using namespace std;

string result[2] = { "No", "Yes" };

int main()
{
    Array<int> w;
    w.pushBack(23);
    w.pushBack(10);
    w.pushBack(45);
    w.pushBack(23);
    cout << "W array before sorting to check isUnique1: \n";
    w.print();
    cout << "\n";
    w.checkArrayUniqueness(&isUnique1, 0, w.Size());
    cout << "Is W unique: " << result[w.m_Unique];
    cout << "\n";

    Array<int> x;
    x.pushBack(10);
    x.pushBack(45);
    x.pushBack(9);
    x.pushBack(23);
    cout<< "\nX array before sorting magic trick: \n";
    x.print();
    cout << "\n";

    x.checkArrayUniqueness(&isUnique1, 0, x.Size());
    cout<< "Is X unique: " << result[x.m_Unique];
    cout << "\n";

    Array<int> y;
    y = x;

    cout<< "\nInsertion Sort: \n";
    x.iSort();
    x.print();
    cout << "\n";

    cout<< "Y array before sorting magic trick: \n";
    y.print();
    cout << "\n";

    cout<< "Merge Sort: \n";
    y.mSort();
    y.print();
    cout << "\n";

    y.checkArrayUniqueness(&isUnique2, 0, y.Size());
    cout<< "Is Y unique: " << result[y.m_Unique];
    cout << "\n";

    Array<string> z;
    z.pushBack("Hello");
    z.pushBack("Hello");

    cout<< "\nZ array, not unique...testing to make sure the unique knows this: \n";
    z.print();
    cout << "\n";
    z.checkArrayUniqueness(&isUnique2, 0, z.Size());
    cout<< "Is Z unique: " << result[z.m_Unique];
    cout << "\n";

    MinHeap<int> mH1;
    mH1.push(10);
    mH1.push(45);
    mH1.push(9);
    mH1.push(23);
    cout<< "\nIs mH1 unique: " << result[isUnique3MH(mH1, 0, mH1.data.size())];
    cout << "\n";
    cout<< "\nMinHeap1 sort magic trick: \n";
    mH1.print_data();

    MinHeap<int> mH2;
    mH2.push(10);
    mH2.push(45);
    mH2.push(23);
    mH2.push(23);
    cout<< "\nIs mH2 unique: " << result[isUnique3MH(mH2, 0, mH2.data.size())];
    cout << "\n";

    cout<< "\nMinHeap2 sort magic trick: \n";
    mH2.print_data();

}
