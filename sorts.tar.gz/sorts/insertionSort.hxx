#ifndef INSERTIONSORT_HXX
#define INSERTIONSORT_HXX

#include <string>
#include <vector>
using namespace std;

//http://mathbits.com/MathBits/CompSci/Arrays/Insertion.htm

template<typename T>
void insertionSort(vector <T> & array)
{
     int i, j, arraySize = array.size();
     T key;
     for(j = 1; j < arraySize; j++)    // Start with 1 (not 0)
    {
           key = array[j];
           for(i = j - 1; (i >= 0) && (array[i] < key); i--)   // Smaller values move up
          {
                 array[i+1] = array[i];
          }
         array[i+1] = key;    //Put key into its proper location
     }
}

#endif // INSERTIONSORT_HXX
