#ifndef POLYGON_HXX
#define POLYGON_HXX

class polygon
{

public:
    virtual ~polygon();
    virtual double area() = 0;
    virtual double perimeter() = 0;
    virtual void showPerimeter() = 0;
    virtual void showArea() = 0;

};

#endif // POLYGON_HXX
