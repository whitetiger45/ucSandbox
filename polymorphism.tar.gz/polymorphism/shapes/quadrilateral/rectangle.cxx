#include "rectangle.hxx"
#include <iostream>

rectangle::~rectangle()
{
}

double rectangle::area()
{
  return (m_width * m_height);
}

double rectangle::perimeter()
{
    return (2 * (m_width + m_height));
}

void rectangle::showArea()
{
    std::cout << "Area of rectangle: " << area() << "\n";
}

void rectangle::showPerimeter()
{
    std::cout << "Perimeter of rectangle: " << perimeter() << "\n";
}
