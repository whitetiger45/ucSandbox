#ifndef SQUARE_HXX
#define SQUARE_HXX

// square inherits quadrilateral
#include "quadrilateral.hxx"

class square
    : public quadrilateral
{

public:
    ~square();
    double area();
    double perimeter();
    void showArea();
    void showPerimeter();
};

#endif // SQUARE_HXX
