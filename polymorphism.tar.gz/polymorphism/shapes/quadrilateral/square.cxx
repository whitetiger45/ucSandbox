#include "square.hxx"
#include <iostream>

square::~square()
{
}

double square::area()
{
    return (m_width * m_height);
}

double square::perimeter()
{
    return (2 * (m_width * m_height));
}

void square::showArea()
{
    if(m_width != m_height){
        std::cout << "Your square does not have equal width and height.";
    }else{
        std::cout << "Area of square: " << area() << "\n";
    }
}

void square::showPerimeter()
{
    if(m_width != m_height){
        std::cout << "\nYour square does not have equal width and height.";
    }else{
        std::cout << "Perimeter of square: " << perimeter() << "\n";
    }
}
