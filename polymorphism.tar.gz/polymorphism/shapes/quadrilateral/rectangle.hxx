#ifndef RECTANGLE_HXX
#define RECTANGLE_HXX

// rectangle inherits quadrilateral
#include "quadrilateral.hxx"

class rectangle
    : public quadrilateral
{

public:
    ~rectangle();
    double area();
    double perimeter();
    void showArea();
    void showPerimeter();
};

#endif // RECTANGLE_HXX
