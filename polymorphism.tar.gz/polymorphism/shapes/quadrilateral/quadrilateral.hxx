#ifndef QUADRILATERAL_HXX
#define QUADRILATERAL_HXX

// Quadrilateral inherits polygon
#include "polygon.hxx"

class quadrilateral
    : public polygon
{

public:
    ~quadrilateral();
    double area();
    double perimeter();
    void addDimensions( double w, double h );

//quadrilateral specific methods
    void showDimensions();
    void showPerimeter();
    void showArea();
protected:
    double m_width;
    double m_height;
};

#endif // QUADRILATERAL_HXX
