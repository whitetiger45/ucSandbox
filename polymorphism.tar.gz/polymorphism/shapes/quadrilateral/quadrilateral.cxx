#include "quadrilateral.hxx"
#include <iostream>

quadrilateral::~quadrilateral()
{
}

double quadrilateral::area()
{
    return (m_width * m_height / 2);
}

double quadrilateral::perimeter()
{
    return (m_width * m_height * m_height);
}

void quadrilateral::addDimensions(double w, double h)
{
    m_width = w;
    m_height = h;
}

void quadrilateral::showArea()
{
    std::cout << "Area of quadrilateral: " << area() << "\n";
}

void quadrilateral::showPerimeter()
{
    std::cout << "Perimeter of quadrilateral: " << perimeter() << "\n";
}
