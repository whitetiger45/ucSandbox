#include <cmath>
#include <iostream>
#include "octagon.hxx"

octagon::~octagon()
{
}

double octagon::area()
{
    return ((2.00) * ( 1.00 + (sqrt(2.00)) * (m_side * m_side)));
}

double octagon::perimeter()
{
    return (8.00 * m_side);
}

void octagon::showPerimeter()
{
    std::cout << "Perimeter of octagon: " << perimeter() << "\n";
}

void octagon::showArea()
{
    std::cout << "Area of octagon: " << area() << "\n";
}

void octagon::addDimensions( double s )
{
    m_side = s;
}

void octagon::changeSide( double s )
{
    m_side = s;
}
