#ifndef OCTAGON_HXX
#define OCTAGON_HXX

#include "polygon.hxx"

class octagon
    : public polygon
{
public:
     ~octagon();
     double area();
     double perimeter();
     void showPerimeter();
     void showArea();

//octagon specific methods
    void addDimensions ( double s );
    void changeSide ( double s );

protected:
    double m_side;

};

#endif // OCTAGON_HXX
