#ifndef EQUILATERALTRIANGLE_HXX
#define EQUILATERALTRIANGLE_HXX

#include "triangle.hxx"

class equilateraltriangle
    : public triangle
{

public:
    ~equilateraltriangle();
    double area();
    double perimeter();
    void showArea();
    void showPerimeter();

};

#endif // EQUILATERALTRIANGLE_HXX
