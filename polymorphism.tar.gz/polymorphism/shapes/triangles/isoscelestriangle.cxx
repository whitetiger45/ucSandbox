#include <iostream>
#include "isoscelestriangle.hxx"

isoscelestriangle::~isoscelestriangle()
{
}

double isoscelestriangle::area()
{
    return ((m_base * m_height) / 2.00 );
}

double isoscelestriangle::perimeter()
{
    return ((2.00 * m_side) + m_base);
}

void isoscelestriangle::showArea()
{
    std::cout << "Area of isosceles triangle: " << area() << "\n";
}

void isoscelestriangle::showPerimeter()
{
    std::cout << "Perimeter of isosceles triangle: " << perimeter() << "\n";
}
