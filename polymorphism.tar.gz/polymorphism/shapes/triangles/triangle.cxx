#include <iostream>
#include "triangle.hxx"

triangle::~triangle()
{
}

double triangle::area()
{
    return ((m_base * m_height) / 2);
}

double triangle::perimeter()
{
    return (m_base + m_side + m_side);
}

void triangle::showArea()
{
    std::cout << "Area of triangle: " << area() << "\n";
}

void triangle::showPerimeter()
{
    std::cout << "Perimeter of triangle: " << perimeter() << "\n";
}

void triangle::addDimensions(double b, double h, double s)
{
    m_base = b;
    m_height = h;
    m_side = s;
}

void triangle::changeBase( double b )
{
    m_base = b;
}

void triangle::changeHeight( double h )
{
    m_height = h;
}

void triangle::changeSide( double s )
{
    m_side = s;
}

