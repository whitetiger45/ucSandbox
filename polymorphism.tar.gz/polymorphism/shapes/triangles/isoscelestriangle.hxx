#ifndef ISOSCELESTRIANGLE_HXX
#define ISOSCELESTRIANGLE_HXX

#include "triangle.hxx"

class isoscelestriangle
    : public triangle
{
public:
    ~isoscelestriangle();
    double area();
    double perimeter();
    void showArea();
    void showPerimeter();
};

#endif // ISOSCELESTRIANGLE_HXX
