#ifndef TRIANGLE_HXX
#define TRIANGLE_HXX

#include "polygon.hxx"

class triangle
    : public polygon
{

public:
//the virtual methods inherited from the abstract polygon class
    ~triangle();
    double area();
    double perimeter();
    void showArea();
    void showPerimeter();

//triangle specific methods
    void addDimensions ( double b, double h, double s );
    void changeBase ( double b );
    void changeHeight ( double h );
    void changeSide ( double s );

protected:
    double m_base;
    double m_height;
    double m_side;
};

#endif // TRIANGLE_HXX
