#include <cmath>
#include <iostream>

#include "equilateraltriangle.hxx"

equilateraltriangle::~equilateraltriangle()
{
}

double equilateraltriangle::area()
{
    return (((sqrt(3.00))/4) * (m_side * m_side));
}

double equilateraltriangle::perimeter()
{
    return (3.00 * m_side);
}

void equilateraltriangle::showArea()
{
    std::cout << "Area of equilateral triangle: " << area() << "\n";
}

void equilateraltriangle::showPerimeter()
{
    std::cout << "Perimeter of equilateral triangle: " << perimeter() << "\n";
}
