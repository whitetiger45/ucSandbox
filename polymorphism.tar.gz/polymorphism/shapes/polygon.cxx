#include <iostream>

#include "polygon.hxx"

polygon::~polygon()
{
}
