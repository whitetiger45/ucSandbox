/*
 *Author: Bryan Kanu, Dan Wendelken, Jed Lantikus
 *Course title: Data Structures
 *Course number: CS2028
 *Instructor: Anca Ralescu
 *TA: Suryadip Chakraborty
 *Abstract: Assignment 1 main.cxx uses the abstract interface
 * Polygon and abstract functions area()
 * and perimeter() to implement classes for
 * and to compute their respective areas and perimeters.
 */

#include <iostream>

#include "equilateraltriangle.hxx"
#include "isoscelestriangle.hxx"
#include "polygon.hxx"
#include "rectangle.hxx"
#include "square.hxx"

using namespace std;

int main()
{
    cout<< "\n***************\n-------------\nPolygon Creator\n***************\n-------------\n";
    cout << "What type of polygon would you like to create?\n";
    cout << "-------------\nA.\n(Triangles)\n\n1: Triangle\n2: Equilateral Triangle\n3: Isosceles Triangle\n";
    cout << "-------------\n";
    cout << "B.\n(Quadrilaterals)\n\n4: Quadrilateral\n5: Square\n6: Rectangle\n------------\n";

    int userInput = 0;

    cout<< "Enter digit: ";
    cin >> userInput;

    polygon * x;
    triangle trgl;
    equilateraltriangle eqtrgl;
    isoscelestriangle isostrgl;
    quadrilateral quad;
    rectangle rect;
    square sqr;
    double b, h, s, w, l;

    switch(userInput)
    {
        case 1:
            cout <<"Enter the base of the triangle: ";
            cin >> b;
            cout <<"Enter the height of the triangle: ";
            cin >> h;
            cout <<"Enter the length of the sides of your triangle: ";
            cin >> s;
            trgl.addDimensions(b, h, s);
            x = &trgl;
            //triangle object being pointed to by x;
            x->showArea();
            x->showPerimeter();
            break;

        case 2:
            cout <<"Enter the base of the equilateral triangle: ";
            cin >> b;
            cout <<"Enter the height of the equilateral triangle: ";
            cin >> h;
            cout <<"Enter the length of the sides of your equilateral triangle: ";
            cin >> s;
            eqtrgl.addDimensions(b, h, s);
            x = &eqtrgl;
            //equilateral triangle object being pointed to by x;
            x->showArea();
            x->showPerimeter();
            break;

        case 3:
            cout <<"Enter the base of the isosceles triangle: ";
            cin >> b;
            cout <<"Enter the height of the isosceles triangle: ";
            cin >> h;
            cout <<"Enter the length of the sides of your isosceles triangle: ";
            cin >> s;
            isostrgl.addDimensions(b, h, s);
            x = &isostrgl;
            //isosceles triangle object
            x->showArea();
            x->showPerimeter();
            break;

        case 4:
            cout <<"Enter the height of your quadrilateral: ";
            cin >> h;
            cout <<"Enter the width of your quadrilateral: ";
            cin >> w;
            quad.addDimensions(w, h);
            x = &quad;
            //quadrilateral object
            x->showArea();
            x->showPerimeter();
            break;

        case 5:
            cout <<"Enter the height of your square: ";
            cin >> h;
            cout <<"Enter the width of your square: ";
            cin >> w;
            sqr.addDimensions(w, h);
            x = &sqr;
            //square object
            x->showArea();
            x->showPerimeter();
            break;

        case 6:
            cout <<"Enter the height of your rectangle: ";
            cin >> h;
            cout <<"Enter the width of your rectangle: ";
            cin >> w;
            rect.addDimensions(w, h);
            x = &rect;
            //square object
            x->showArea();
            x->showPerimeter();
            break;

        default:
            cout<< "You have entered an invalid option!";
            EXIT_SUCCESS;
    }

    cout << "\n";

    return 0;
}
