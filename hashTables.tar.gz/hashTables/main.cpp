/*
 *Author: Bryan Kanu, Dan Wendelken, Jed Lantikus
 *Course title: Data Structures
 *Course number: CS2028
 *Instructor: Anca Ralescu
 *TA: Suryadip Chakraborty
 *Abstract:
 * The purpose of this programming project is to gain experience with:
 *      (1) hash functions
 *      (2) hash table implementation
 *      (3) evaluate the performance of different collision-resolution methods.
 */

#include <cmath>
#include <iostream>

#include "chainHash.h"
#include "uMap.h"

using namespace std;

enum {lP = 1, dH, qP, cH};

int main()
{
    HashMap a;
    LHashMap b;

    double ratio = 0.00;

    cout << "Enter a load ratio...Range is (.1 - 1)%: ";
    cin >> ratio;
    cout << "\n";

    while(ratio < 0.1 || ratio > 1.00)
    {
        cout << "Enter a load ratio...Range is (.1 - 1)%: ";
        cin >> ratio;
        cout << "\n";
    }

    int tableRatio = ceil(ratio * TABLE_SIZE);

    cout <<"\nRatio : " << ratio << ", Table Ratio: " << tableRatio << "\n";
    int collisionResolution, elementCount;
    collisionResolution = 0, elementCount = 0;
    cout << "Choose your method of collision resolution:\n(Enter digit)\n";
    cout << "1 - Linear Probing\n2 - Double Hash\n3 - Quadratic Hash\n4 - Chain Hash\n";
    cout << "Method: ";
    cin >> collisionResolution;

    int ratioTracker = 0;
    int x = 0;
    double value;
    do//Part 1
    {
        switch(collisionResolution)
        {
            case lP:

                cout << ++x << ")Enter value: ";
                cin >> value;
                a.linearProbe(value);
                break;

            case dH:

                cout << ++x << ")Enter value: ";
                cin >> value;
                a.doubleHash(value);
                break;

            case qP:

                cout << ++x << ")Enter value: ";
                cin >> value;
                a.quadraticProbing(value);
                break;

            case cH:

                cout << ++x << ") Enter value: ";
                cin >> value;
                b.chainHash(value);
                break;

            default:
                a.linearProbe(value);
        };

        ratioTracker++;
    }while(ratioTracker <= tableRatio && a.getEntryCount() <= TABLE_SIZE);

    cout << "Load Ratio Exceeded!\n\nHash Table:\n---------\n";
    if(collisionResolution != cH)
        a.print();
    else
        b.print();

    cout << "\n";
//Search for a specific key
    cout <<"Enter key to search for: ";
    int key;
    cin >> key;
    if(collisionResolution != cH)
    {
        cout << "\nKey: " << key;
        if(a.get(key) != -1)
            cout << ", Value: " << a.get(key) << "\n";
        else
            cout << "\nKey does not exist!\n";
    }
    else
    {
        cout << "\nKey: " << key;
        if(b.get(key) != -1)
            cout << ", Value: " << b.get(key) << "\n";
        else
            cout << "\nKey does not exist!\n";
    }

     return 0;
}
