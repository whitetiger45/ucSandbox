#ifndef CHAINHASH_H
#define CHAINHASH_H

#include <iostream>
#include "uMap.h"

//http://www.algolist.net/Data_structures/Hash_table/Chaining
class LinkedHashEntry
{

private:
    int key;
    int value;
    LinkedHashEntry *next;

public:
    LinkedHashEntry(int key, int value)
    {
        this->key = key;
        this->value = value;
        this->next = NULL;
    }

    int getKey()
    {
        return key;
    }

    int getValue()
    {
        return value;
    }

    void setValue(int value)
    {
        this->value = value;
    }

    LinkedHashEntry *getNext()
    {
        return next;
    }

    void setNext(LinkedHashEntry *next)
    {
        this->next = next;
    }
};

class LHashMap
{

private:

    int m_entryCount;
    LinkedHashEntry **table;

public:

    LHashMap()
    {
        table = new LinkedHashEntry*[TABLE_SIZE];

        for(int i = 0; i < TABLE_SIZE; i++)
            table[i] = NULL;

        m_entryCount = 0;
    }

    int get(int key)
    {
        int hash = (key % TABLE_SIZE);

        if(table[hash] == NULL)
        {
            return -1;
        }

        else
        {
            LinkedHashEntry *entry = table[hash];

            while (entry != NULL && entry->getKey() != key)
                entry = entry->getNext();

            if(entry == NULL)
                return -1;

            else
                return entry->getValue();
        }
    }

    void put(int key, int value)
    {

        int hash = (key % TABLE_SIZE);

        if(table[hash] == NULL)
        table[hash] = new LinkedHashEntry(key, value);

        else
        {
            LinkedHashEntry *entry = table[hash];

            while(entry->getNext() != NULL)
                entry = entry->getNext();

            if(entry->getKey() == key)
                entry->setValue(value);
            else
                entry->setNext(new LinkedHashEntry(key, value));
        }
    }

    int chainHash(int value)
    {
        int collisions = 0;
        int hash = (value % TABLE_SIZE);

        int repeat = get(hash);

        while(!positionEmpty(hash))
        {
            collisions++;
            hash++;
        }

//        if(repeat == value)//this is to make sure duplicate entries are not inserted
//        {
//            std::cout << "Value already exists!\n\n";
//            return collisions;
//        }

        if(table[hash] == NULL)
            table[hash] = new LinkedHashEntry(hash, value);
        else
        {
//            LinkedHashEntry *entry = table[hash];
            table[hash] = new LinkedHashEntry(hash, value);
        }

        m_entryCount++;
        std::cout << "Collisions: " << collisions << "\n\n";
        return collisions;
    }

    void remove(int key)
    {
        int hash = (key % TABLE_SIZE);
        if (table[hash] != NULL)
        {
              LinkedHashEntry *prevEntry = NULL;
              LinkedHashEntry *entry = table[hash];

              while (entry->getNext() != NULL && entry->getKey() != key)
              {
                    prevEntry = entry;
                    entry = entry->getNext();
              }

              if (entry->getKey() == key)
              {
                    if(prevEntry == NULL)
                    {
                        LinkedHashEntry *nextEntry = entry->getNext();
                        delete entry;
                        table[hash] = nextEntry;
                    }
                    else
                    {
                        LinkedHashEntry *next = entry->getNext();
                        delete entry;
                        prevEntry->setNext(next);
                    }
              }
        }
    }

    ~LHashMap()
    {
        for (int i = 0; i < TABLE_SIZE; i++)
            if (table[i] != NULL)
            {
                LinkedHashEntry *prevEntry = NULL;
                LinkedHashEntry *entry = table[i];

                while (entry != NULL)
                {
                    prevEntry = entry;
                    entry = entry->getNext();
                    delete prevEntry;
                }
            }
        delete[] table;
    }

    void print()
    {
        int count = 1;
        for (int i = 0; i < TABLE_SIZE; i++)
            if (table[i] != NULL)
            {
                LinkedHashEntry *entry = table[i];
                std::cout << count++ << ") key: " << entry->getKey() << ", value: " << entry->getValue() << "\n";
            }
    }

    bool positionEmpty(int key)
    {
        if(table[key] != NULL)
            return false;
        else
            return true;
    }

};
#endif // CHAINHASH_H
