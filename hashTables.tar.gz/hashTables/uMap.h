#ifndef UMAP_H
#define UMAP_H

#include "chainHash.h"


//http://www.algolist.net/Data_structures/Hash_table/Simple_example
class HashEntry
{

private:

    int m_key;
    int m_value;

public:

    HashEntry(int key, int value)
    {
        this->m_key = key;
        this->m_value = value;
    }

    int getKey()
    {
        return m_key;
    }

    int getValue()
    {
        return m_value;
    }

};

const int TABLE_SIZE = 23;

class HashMap
{

private:

    HashEntry **table;
    int m_entryCount;

public:

    HashMap()
    {
        table = new HashEntry*[TABLE_SIZE];

        for (int i = 0; i < TABLE_SIZE; i++)
            table[i] = NULL;

        m_entryCount = 0;
    }

    ~HashMap()
    {
        for (int i = 0; i < TABLE_SIZE; i++)
            if (table[i] != NULL)
                delete table[i];

        delete[] table;
        m_entryCount = 0;
    }

    int get(int key)
    {
        int hash = (key % TABLE_SIZE);

        while (table[hash] != NULL && table[hash]->getKey() != key)
            hash = (hash + 1) % TABLE_SIZE;

        if (table[hash] == NULL)
        {
            return -1;
        }

        else
            return table[hash]->getValue();
    }

    void print()
    {
        static int valueCount = 0;
        static int entry = 0;

        if(m_entryCount == 0)
            return;

        while (valueCount != m_entryCount)
        {
            if(table[entry] != NULL)
            {
                std::cout << valueCount+1 << ") key: " << table[entry]->getKey() << ", value: " << table[entry]->getValue() << "\n";
                valueCount++;
                entry++;
            }
            else
            {
                entry++;
                continue;
            }
        }
    }

    int linearProbe(int key, int value)//this method returns the number of collisions
    {
        int hash = (key % TABLE_SIZE);
        int collisions = 0;
        int repeat = 0;

        repeat= get(hash);

        if(tableFull())
        {
            std::cout << "Table is full!";
            return 0;
        }

        while (table[hash] != NULL)
        {
            hash = (hash + 1) % TABLE_SIZE;
            collisions++;
        }

        std::cout << "Collisions: " << collisions << "\n\n";

        if (table[hash] != NULL)
            delete table[hash];

//        if(repeat == value)//this is to make sure duplicate entries are not inserted
//        {
//            std::cout << "Value already exists!\n\n";
//            return collisions;
//        }

        table[hash] = new HashEntry(hash, value);
        m_entryCount++;

        return collisions;
    }

    int linearProbe(int value)//this method returns the number of collisions
    {
        int hash = (value % TABLE_SIZE);
        int collisions = 0;
        int repeat = get(hash);

        if(tableFull())
        {
            std::cout << "Table is full!";
            return 0;
        }

        while (table[hash] != NULL)
        {
            hash = (hash + 1) % TABLE_SIZE;
            collisions++;
        }

        std::cout << "Collisions: " << collisions << "\n\n";

        if (table[hash] != NULL)
            delete table[hash];

        if(repeat == value)//this is to make sure duplicate entries are not inserted
        {
            std::cout << "Value already exists!\n\n";
            return collisions;
        }

        table[hash] = new HashEntry(hash, value);
        m_entryCount++;

        return collisions;
    }

    int doubleHash(int value, int q)//this method returns the number of collisions
    {
        int hash = (value % TABLE_SIZE);
        int collisions = 0;

        if(tableFull())
        {
            std::cout << "Table is full!";
            return 0;
        }

        while(table[hash] != NULL && (hash < TABLE_SIZE || hash > 0))
        {
            hash = (hash % (q/2));//second hash function
            collisions++;
        }

        std::cout << "Collisions: " << collisions << "\n\n";

        if (table[hash] != NULL)
            delete table[hash];

        table[hash] = new HashEntry(hash, value);
        m_entryCount++;

        return collisions;
    }

    int doubleHash(int value)//this method returns the number of collisions
    {
        int hash = (value % TABLE_SIZE);
        int collisions = 0;
        int repeat = get(hash);

        if(tableFull())
        {
            std::cout << "Table is full!";
            return 0;
        }


        while(table[hash] != NULL)
        {
            hash = (hash % TABLE_SIZE - 5);//second hash function
            if(hash < 0)
                hash = 0 + collisions;
            if(hash > TABLE_SIZE)
                hash = TABLE_SIZE - collisions;
            collisions++;
        }

        std::cout << "Collisions: " << collisions << "\n\n";

        if (table[hash] != NULL)
            delete table[hash];

//        if(repeat == value)//this is to make sure duplicate entries are not inserted
//        {
//            std::cout << "Value already exists!\n\n";
//            return collisions;
//        }

        table[hash] = new HashEntry(hash, value);
        m_entryCount++;

        return collisions;
    }

//https://en.wikipedia.org/wiki/Quadratic_probing
    int quadraticProbing(int value)
    {
        int j = 0, hash = 0, collisions = 0;
        hash = value % TABLE_SIZE;
        int repeat = get(hash);

        if(tableFull())
        {
            std::cout << "Table is full!";
            return 0;
        }

        while(table[hash] != NULL)
        {
            hash = (value + j * j) % TABLE_SIZE;//second hash function
            if(hash < 0)
                hash = 0 + collisions;
            else if(hash > TABLE_SIZE)
                hash = TABLE_SIZE - collisions;
            collisions++;
            j++;
        }

        std::cout << "Collisions: " << collisions << "\n\n";

        if (table[hash] != NULL)
            delete table[hash];

//        if(repeat == value)//this is to make sure duplicate entries are not inserted
//        {
//            std::cout << "Value already exists!\n\n";
//            return collisions;
//        }

        table[hash] = new HashEntry(hash, value);
        m_entryCount++;

        return collisions;
    }

    bool tableFull()
    {
        if(m_entryCount == TABLE_SIZE)
            return true;
        else
            return false;
    }

    int getEntryCount()
    {
        return m_entryCount;
    }
};

#endif // UMAP_H
